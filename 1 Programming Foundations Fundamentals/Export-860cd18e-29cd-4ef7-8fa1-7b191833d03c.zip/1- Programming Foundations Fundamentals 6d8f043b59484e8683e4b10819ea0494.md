# 1- Programming Foundations: Fundamentals

## Header

```jsx
- Bug : something Unexpected happens 
- Crash: stops early or Freezes 

- Change source code to machine code 
  - compile it              -> c , c++ 
  - interpret it            -> PHP JS 
  - combination of both     -> JAVA , Python , C# 

- IDE == Integrated Development Enviroments 

- Statment  --> Keyword , Expresion , Operators 

- Types of Errors 
 1: Sentax    --> language role broken     
 2: Running   --> Unable to execute      --> 10/0 
 3: Semantic  --> Unexpected Output 
 
```

# Certificate

[CertificateOfCompletion_Programming Foundations Fundamentals.pdf](1-%20Programming%20Foundations%20Fundamentals%206d8f043b59484e8683e4b10819ea0494/CertificateOfCompletion_Programming_Foundations_Fundamentals.pdf)